import Article from "./components/article";
import Footer from "./components/footer";
import Header from "./components/header";
import MainComp from "./components/maincomp";

let App = () => {
    return <div>
            <h2>Welcome to your life</h2>
            <Header/>
              <MainComp version="1001" created="24th July" first="Past" second="Present" title="DB Application"/>
            <Footer/>
           </div>
}
export default App;