import compstyle from "./config";

let Footer = () => {
    return <div style={ {...compstyle, height : "50px",lineHeight : "50px"} }>
            <h3>Footer Component</h3>
           </div>
}
export default Footer;