/* eslint-disable react/prop-types */
let Article = (props) => {
    return <div>
            <h3>{props.title}</h3>
            <h4>Version is : {props.version} Created on  : {props.created}</h4>
            <div>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit officia totam, sunt qui modi laboriosam ipsa ratione! Facilis nihil, earum laudantium officia nemo laborum nisi exercitationem dolor, esse, sapiente magni.
                Quia, officiis veritatis! Eos provident, ad officiis repudiandae unde, adipisci excepturi quod numquam rerum cupiditate inventore dolorem ducimus qui natus odio veritatis, labore repellendus quia? Sit neque laborum reiciendis facilis!
                Earum corporis maiores illo nobis consequatur dicta recusandae. Quaerat accusantium rem ex commodi, vitae aut itaque consequuntur adipisci doloribus laborum totam blanditiis molestiae porro quia aliquam cupiditate ratione mollitia ab!
                Voluptas laborum itaque atque facilis, sunt ex tempore cum autem adipisci veritatis consequatur vel iusto delectus tempora officia ad reprehenderit minima similique dolore sapiente sed dicta laboriosam libero. Vitae, voluptatem.
                Dolore, omnis. Sed dolorum blanditiis vitae ducimus, porro quibusdam dolorem reprehenderit! Quod nostrum assumenda, tenetur beatae necessitatibus sunt id, reprehenderit illum labore iure magnam minima aut ex amet! Quam, tenetur?
            </div>
           </div>
}
export default Article;