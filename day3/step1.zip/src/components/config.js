let compstyle = {
    backgroundColor : "tomato", 
    textAlign:"center", 
    height : "100px", 
    lineHeight : "100px", 
    fontFamily:"sans-serif" 
}
export default compstyle;