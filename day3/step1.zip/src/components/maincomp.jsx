import Article from "./article";

/* eslint-disable react/prop-types */
let MainComp = (props) => {
    return <div>
            <h3>MainComp Component { props.title }</h3>
               {/*  <Article version={props.version} created={props.created} title={props.first}/>
                <Article version={props.version} created={props.created} title={props.second}/> */}
                 <Article {...props} title={props.first}/>
                 <Article version={props.version} created={props.created} title={props.second}/>
           </div>
}
export default MainComp;