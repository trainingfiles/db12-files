import compstyle from "./config";

let Header = () => {
    return <div style={ compstyle }>
            <h3>Header Component</h3>
           </div>
}
export default Header;