import { useState } from "react";
import HeroList from "./component/herolist";
import UsersList from "./component/users";

let App = () => {
    // console.log(useState());// [state, setState]
    let [power, setPower] = useState(10);

    let setPowerTo100 = () => {
      setPower(100)
    }

    return <div>
            <h2>Welcome to your life</h2>
            <h3>Power {power}</h3>
            <button onClick={setPowerTo100}>Click Me to set power to 100</button>
            <hr />
            <HeroList/>
            <hr />
            <UsersList/>
           </div>
}
export default App;