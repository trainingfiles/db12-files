let App = () => {
  return <div className="container">
            <h1>React - Redux</h1>
            <hr />
         </div>
};

export default App;