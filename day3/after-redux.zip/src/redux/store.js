import { legacy_createStore } from "redux"
import heroreducer from "./hero/reducers/hero.reducers"

const store = legacy_createStore(heroreducer);

export default store;