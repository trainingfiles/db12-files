import { ADD_HERO } from "../types/hero.types";

let addHero = () => {
    return {
        type : ADD_HERO
    }
}

export {addHero};