import { ADD_HERO } from "../types/hero.types"

let initialState = {
    numberOfHeroes : 1
};

let heroreducer = (state = initialState, action) => {
    switch(action.type){
        case ADD_HERO : return { numberOfHeroes : state.numberOfHeroes + 1 }
        default : return state
    }
};

export default heroreducer;