import HeroComp from "./components/hero";
import { Provider } from "react-redux";
import store from "./redux/store";
import SideKickComp from "./components/sidekick";

let App = () => {
  return <div className="container">
            <h1>React - Redux</h1>
            <hr />
            <Provider store={store}>
              <HeroComp/>
              <SideKickComp/>
            </Provider>
         </div>
};

export default App;