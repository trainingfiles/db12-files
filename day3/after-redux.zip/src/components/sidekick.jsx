/* eslint-disable react/no-unescaped-entities */
import { useSelector } from "react-redux";

let SideKickComp = () => {
    const numberOfHeroes = useSelector( state => state.numberOfHeroes );

    return <div className="container">
              <h2>Side kick Component</h2>
              <h3>Number of Avengers : {numberOfHeroes}</h3>
           </div>
  };
  
  export default SideKickComp;