/* eslint-disable react/no-unescaped-entities */
import { useDispatch, useSelector } from "react-redux";
import { addHero } from "../redux";

let HeroComp = () => {
    const numberOfHeroes = useSelector( state => state.numberOfHeroes );
    const dispatch = useDispatch();
    return <div className="container">
              <h2>Avenger's Enrollment Program</h2>
              <h3>Number of Avengers : {numberOfHeroes}</h3>
              <button onClick={()=> dispatch(addHero()) } className="btn btn-primary">Add Avenger</button>
           </div>
  };
  
  export default HeroComp;