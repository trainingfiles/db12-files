/* eslint-disable no-unused-vars */
import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import HomeComp from "./components/home";
import BatmanComp from "./components/batman";
import SupermanComp from "./components/superman";
import FlashComp from "./components/flash";
import NotFoundComp from "./components/notfound";
import "./assets/mystyle.css";
import Batmanmovie1Comp from "./components/batmanmovie1";
import Batmanmovie2Comp from "./components/batmanmovie2";
import { useState } from "react";

let App = () => {
  let [quantity, setQuantity] = useState(10)
  return (
    <div className="container">
      <h1>Routes in React</h1>
      <hr />
      <BrowserRouter>
      {/* 
      <ul className="nav">
       <li className="nav-item"> <Link className="nav-link" to="/">Home</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/batman">Batman</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/batman/movie1">Batman Movie 1</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/batman/movie2">Batman Movie 2</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/superman">Superman</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/flash">Flash</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/hulk">Hulk</Link> </li>
      </ul> 
      */}
      <ul className="nav">
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/">Home</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/batman">Batman</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/batman/movie1">Batman Movie 1</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/batman/movie2">Batman Movie 2</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/superman">Superman</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to={'/flash/'+quantity}>Flash</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/hulk">Hulk</NavLink> </li>
      </ul>
      <Routes>
        <Route path="/" element={<HomeComp/>} />
        <Route path="/batman" element={<BatmanComp/>}>
          <Route path="/batman/movie1" element={<Batmanmovie1Comp/>} />
          <Route path="/batman/movie2" element={<Batmanmovie2Comp/>} />
        </Route>
        <Route path="/superman" element={<SupermanComp/>} />
        <Route path="/flash/:qty" element={<FlashComp/>} />
        <Route path="*" element={<NotFoundComp/>} />
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;