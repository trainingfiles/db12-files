let Batmanmovie2Comp = () => {
    return <div>
                <h2>Batman Movie 2 Component</h2>
            </div>
}

export default Batmanmovie2Comp