let Batmanmovie1Comp = () => {
    return <div>
                <h2>Batman Movie 1 Component</h2>
            </div>
}

export default Batmanmovie1Comp