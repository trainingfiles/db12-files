import UsersComp from "./component/childcomp";

let App = () => {
    return <div className="container">
             <h2>Welcome to your life</h2>
             <UsersComp/>
           </div>
}
export default App;