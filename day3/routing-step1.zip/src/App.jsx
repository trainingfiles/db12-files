import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import HomeComp from "./components/home";
import BatmanComp from "./components/batman";
import SupermanComp from "./components/superman";
import FlashComp from "./components/flash";
import NotFoundComp from "./components/notfound";
import "./assets/mystyle.css";

let App = () => {
  return (
    <div className="container">
      <h1>Routes in React</h1>
      <hr />
      <BrowserRouter>
      <ul className="nav">
       <li className="nav-item"> <Link className="nav-link" to="/">Home</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/batman">Batman</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/superman">Superman</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/flash">Flash</Link> </li>
       <li className="nav-item"> <Link className="nav-link" to="/hulk">Hulk</Link> </li>
      </ul>
      <Routes>
        <Route path="/" element={<HomeComp/>} />
        <Route path="/batman" element={<BatmanComp/>} />
        <Route path="/superman" element={<SupermanComp/>} />
        <Route path="/flash" element={<FlashComp/>} />
        <Route path="*" element={<NotFoundComp/>} />
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;