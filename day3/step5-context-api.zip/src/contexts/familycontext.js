import {createContext} from "react";

export let FamilyContext = createContext();

/* 
FamilyContext.Consumer
FamilyContext.Provider
*/

/* 
let Consumer = FamilyContext.Consumer;
let Provider = FamilyContext.Provider;

export { Consumer, Provider }
 */