import GrandParentComp from "./components/grandcomp";

let App = () => {
    return <div className="container">
             <h2>Context API</h2>
             <GrandParentComp/>
           </div>
}
export default App;