import { useState } from "react";
import ParentComp from "./parentcomp";
import { FamilyContext } from "../contexts/familycontext";
import CousinComp from "./cousincomp";

let GrandParentComp = () => {
    let [power, setPower] = useState(1)
    return <div className="card">
            <div className="card-body">
             <h3 className="card-title">GrandParent Component | power is { power }</h3>
                <button className="btn btn-primary mb-3" onClick={()=> setPower(power + 1)}>Increase Power</button>
                <FamilyContext.Provider value={power} >
                    <ParentComp/>
                    <br />
                    <CousinComp />
                </FamilyContext.Provider>
            </div>
           </div>
}
export default GrandParentComp;