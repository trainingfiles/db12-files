import { useContext } from "react";
import { FamilyContext } from "../contexts/familycontext";

let ChildComp = () => {
  let pow = useContext(FamilyContext);
    return <div className="card">
            <div className="card-body">
                <h3 className="card-title">Child Component</h3>
                <h4>Power set by Grand Parent Component is {pow}</h4>
                <h4>Power set by Grand Parent Component is {pow}</h4>
                <hr />
                <h4>Power set by Grand Parent Component is <FamilyContext.Consumer>{(val) => val}</FamilyContext.Consumer></h4>
                <h4>Power set by Grand Parent Component is <FamilyContext.Consumer>{(val) => val}</FamilyContext.Consumer></h4>
            </div>
           </div>
}
export default ChildComp;