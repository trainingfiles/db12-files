import ChildComp from "./childcomp";

let ParentComp = () => {
    return <div className="card">
                <div className="card-body">
                    <h3 className="card-title">Parent Component</h3>
                    <ChildComp/>
                </div>
           </div>
}
export default ParentComp;