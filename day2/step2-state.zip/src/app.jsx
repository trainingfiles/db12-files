/* 
allows to render on demand
uses lifecycle hooks / events
supports handling error boundries
supports Higher order components / higher order functions 

import { Component } from "react";
class App extends Component{
    render(){
        return <div>
                   <h1>I am Class Component</h1>
               </div>
    }
};
*/

import ClassComp from "./classcomp";

/* 
supports hooks 
*/
let App = () => <div>
                   <h1>I am Function Component</h1>
                   <ClassComp/>
                </div>
export default App;