import { Component } from "react";
import { NestedChild } from "./nestedchild";

export class ChildComp extends Component{
    state = {
        compversion : 0
    }
    constructor(){
        super();
        console.log("ChildComp Component's Constructer was called");
        // this.state.compversion = 10;
    }
    static getDerivedStateFromProps(compprops, compstate){
        // console.log(arguments[0], arguments[1])
        return {
            compversion : compprops.ver * 2
        }
    }
    shouldComponentUpdate(compprops, compstate){
        // console.log(arguments[0], arguments[1])
        if(compprops.ver > 500){
            return false
        }else{
            return true
        }
    }
    render(){
       
        console.log("ChildComp Component's Render was called");
        return <div>
                    <h3> Child Component </h3>
                    <h5>Version {this.props.ver}</h5>
                    <h5>Comp Version {this.state.compversion}</h5>
                    <button onClick={() => this.props.ver = 100 }>Change Parent's Version</button>
                    <NestedChild/>
                </div>
    }
    componentDidMount(){
        console.log("ChildComp Component's componentDidMount was called");
    }
    componentWillUnmount(){
        console.log("ChildComp Component's componentWillUnmount was called");
    }
    componentDidUpdate(){
        console.log("ChildComp Component's componentDidUpdate was called");
    }
}