import { Component } from "react";

export class NestedChild extends Component{
    constructor(){
        super();
        console.log("NestedChild Component's Constructer was called");
    }
    render(){
        console.log("NestedChild Component's Render was called");
        return <div>
                    <h4>
                        Nested Child Component
                    </h4>
                </div>
    }

    componentDidMount(){
        console.log("NestedChild Component's componentDidMount was called");
    }
    componentWillUnmount(){
        console.log("NestedChild Component's componentWillUnmount was called");
    }

    componentDidUpdate(){
        console.log("NestedChild Component's componentDidUpdate was called");
    }

}