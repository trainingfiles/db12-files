let ElementFun = function(){
    let avengers = ["Ironman","Thor","Hulk"];
    return avengers.map(function(val){
        return <li>{val}</li>
    })
}
// export
// export { ElementFun }
// export with alias name
// export { ElementFun as Ef }
// default export
export default ElementFun;