import React, { Component } from "react";
class App extends Component{
    state = {
        power : 0
    }
   /* numRef = React.createRef(); */
   /*  
   constructor(){
        super();
        this.addPower = this.addPower.bind(this);
    } 
    */
    numRef = React.createRef();
    render(){
        return <div>
                   <h2>I am Class Component</h2>
                   {/* <button onClick={this.addPower.bind(this)}>Increase Power</button> */}
                   {/* <button onClick={this.addPower}>Increase Power</button> */}
                   <button onClick={this.addPower}>Increase Power</button>
                   <br />
                   {/* <input ref={this.numRef} onChange={this.increasePowerRange} type="range" /> */}
                   <input onChange={(event)=> this.increasePowerRange(event)} type="range" />
                   <br />
                   <input ref={this.numRef} type="number" />
                   <button onClick={this.increasePowerNumber}>Set Power from Number</button>
                   <h3>Power is { this.state.power }</h3>
               </div>
    }
    addPower = () => {
        this.setState({
            power : this.state.power + 1
        })
    }
    increasePowerRange = (evt) => {
        this.setState({
            power : Number(evt.target.value)
        })
    }
    increasePowerNumber = () => {
        this.setState({
            power : Number(this.numRef.current.value)
        })
    }
};
export default App;