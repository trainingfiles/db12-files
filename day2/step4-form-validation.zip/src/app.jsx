import React, { Component } from "react";
class App extends Component{
    state = {
        userinfo : {
            title : "default",
            firstname : "default",
            lastname : "default",
            city : "default",
            power : 0
        },
        forminfo : {
            title : "default",
            firstname : "default",
            lastname : "default",
            city : "default",
            power : 0
        }
    }
    render(){
        return <div className="container">
                   <h2>User Registeration Form</h2>
                   <div className="mb-3">
                        <label className="form-label" htmlFor="title">User Title</label>
                        <input value={this.state.title} onInput={this.setUserInfo} className="form-control" id="title" type="text" />
                   </div>
                   <div className="mb-3">
                        <label className="form-label" htmlFor="firstname">First Name</label>
                        <input value={this.state.firstname} onInput={this.setUserInfo} className="form-control" id="firstname" type="text" />
                   </div>
                   <div className="mb-3">
                        <label className="form-label" htmlFor="lastname">Last Name</label>
                        <input value={this.state.lastname} onInput={this.setUserInfo} className="form-control" id="lastname" type="text" />
                   </div>
                   <div className="mb-3">
                        <label className="form-label" htmlFor="city">City</label>
                        <input value={this.state.city} onInput={this.setUserInfo} className="form-control" id="city" type="text" />
                   </div>
                   <div className="mb-3">
                        <label className="form-label" htmlFor="power">Power</label>
                        <input defaultValue={this.state.power} onChange={this.setUserInfo} className="form-control" id="power" type="number" />
                   </div>
                   <div className="col-auto">
                        <button onClick={this.formClickHandler} className="btn btn-primary mb-3">Register</button>
                   </div> 
                   <hr />
                   <ul>
                        <li>User Title : {this.state.userinfo.title}</li>
                        <li>First Name : {this.state.userinfo.firstname}</li>
                        <li>Last Name : {this.state.userinfo.lastname}</li>
                        <li>City : {this.state.userinfo.city}</li>
                        <li>Power : {this.state.userinfo.power}</li>
                   </ul>
                   <ul>
                        <li>User Title : {this.state.forminfo.title}</li>
                        <li>First Name : {this.state.forminfo.firstname}</li>
                        <li>Last Name : {this.state.forminfo.lastname}</li>
                        <li>City : {this.state.forminfo.city}</li>
                        <li>Power : {this.state.forminfo.power}</li>
                   </ul>
               </div>
    }
   /*  
    setTitle = (evt)=>{
        this.setState({ title : evt.target.value })
    }
    setFirstName = (evt)=>{
        this.setState({ firstname : evt.target.value })
    }
    setLastName = (evt)=>{
        this.setState({ lastname : evt.target.value })
    }
    setCity = (evt)=>{
        this.setState({ city : evt.target.value })
    }
    setPower = (evt)=>{
        this.setState({ power : evt.target.value })
    } 
    */
  /*  setPower = (evt)=>{
    if(Number(evt.target.value) < 10){
        alert("power is too less")
    }else if(Number(evt.target.value) > 50){
        alert("power is too much")
    }else{
        this.setState({ power : evt.target.value })
    }
   }  */
   setUserInfo = (evt) => {
    this.setState({ userinfo : { ...this.state.userinfo, [evt.target.id] : evt.target.value }  })
   }

   formClickHandler = () => {
        if(this.state.userinfo.power < 10){
            alert("power is too less")
        }else if( this.state.userinfo.power > 50){
            alert("power is too much")
        }else{
            this.setState({ ...this.state, forminfo : this.state.userinfo })
        }
   }
};
export default App;